/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package TrabalhoFinalPo;

/**
 *
 * @author jpssa
 */
public enum TipoDespesa {
    TRANSPORTE,
    RESIDENCIA,
    SAUDE,
    EDUCACAO,
    ENTRETENIMENTO,
    ALIMENTACAO;
}
